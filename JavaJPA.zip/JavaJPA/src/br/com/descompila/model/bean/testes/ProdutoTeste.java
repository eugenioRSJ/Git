/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.descompila.model.bean.testes;

import br.com.descompila.model.bean.Categoria;
import br.com.descompila.model.bean.Produto;
import br.com.descompila.model.dao.ProdutoDAO;

/**
 *
 * @author Junior
 */
public class ProdutoTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Categoria cad = new Categoria();
        cad.setId(1);
        Produto produto = new Produto(4, "Arroz", 5, 12.00, cad);
        ProdutoDAO dao = new ProdutoDAO();
        dao.save(produto);
    }
    
}
