/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.descompila.model.bean.testes;

import br.com.descompila.model.bean.Categoria;
import br.com.descompila.model.dao.CategoriaDAO;


/**
 *
 * @author Junior
 */
public class CategoriaTeste {
     public static void main(String[] args ){
         
        
         CategoriaDAO dao = new CategoriaDAO();    
         
            System.out.println("Descrição = " + dao.remove(3));
       
     }
}
