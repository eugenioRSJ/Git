/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbasico;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafxbasico.model.Categoria;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class FXMLControllerController implements Initializable {
    
    @FXML
    private ComboBox<Categoria> cbCategorias;
    private List <Categoria> categoria= new ArrayList<>();
    private ObservableList<Categoria> obsCategoria;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODo
        carregarCAtegorias();
    }    
    
    public void carregarCAtegorias(){
        Categoria categoria1 = new Categoria(1, "Comida");
        Categoria categoria2 = new Categoria(2, "Bebidas");
        categoria.add(categoria1);
        categoria.add(categoria2);
        obsCategoria= FXCollections.observableArrayList(categoria);
        cbCategorias.setItems(obsCategoria);
    }
}
