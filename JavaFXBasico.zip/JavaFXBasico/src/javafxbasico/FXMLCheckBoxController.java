 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbasico;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class FXMLCheckBoxController {

    /**
     * Initializes the controller class.
     */
     @FXML
    private CheckBox cbJava;

    @FXML
    private CheckBox cbPhp;

    @FXML
    void pegarValores() {
        System.out.println(cbJava.selectedProperty().getValue());
        System.out.println(cbPhp.selectedProperty().getValue());
    }
    
}
