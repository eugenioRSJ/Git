package bean;

/**
 *
 * @author Junior
 */
public class buzu {
    private int idBuzu;
    
    public int getIdBuzu() {
        return idBuzu;
    }

    public void setIdBuzu(int idBuzu) {
        this.idBuzu = idBuzu;
    }
    
    @Override
    public String toString() {
        return Integer.toString(getIdBuzu() + 1); 
    }
    
}
