package bean;

/**
 *
 * @author Junior
 */
public class assentoBuzu {
    private int id;
    private int idAssento;
    private int idBuzu;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdAssento() {
        return idAssento;
    }

    public void setIdAssento(int idAssento) {
        this.idAssento = idAssento;
    }

    public int getIdBuzu() {
        return idBuzu;
    }

    public void setIdBuzu(int idBuzu) {
        this.idBuzu = idBuzu;
    }

    @Override
    public String toString() {
        return Integer.toString(getId()); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
