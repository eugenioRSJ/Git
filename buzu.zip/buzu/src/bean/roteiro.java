
package bean;

/**
 *
 * @author Junior
 */
public class roteiro {
    private int id;
    private int idBuzu;
    private int idMotorista;
    private int idOrigem;
    private int idDestino;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdBuzu() {
        return idBuzu;
    }

    public void setIdBuzu(int idBuzu) {
        this.idBuzu = idBuzu;
    }

    public int getIdMotorista() {
        return idMotorista;
    }

    public void setIdMotorista(int idMotorista) {
        this.idMotorista = idMotorista;
    }

    public int getIdOrigem() {
        return idOrigem;
    }

    public void setIdOrigem(int idOrigem) {
        this.idOrigem = idOrigem;
    }

    public int getIdDestino() {
        return idDestino;
    }

    public void setIdDestino(int idDestino) {
        this.idDestino = idDestino;
    }

    @Override
    public String toString() {
        return Integer.toString(getId()); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
