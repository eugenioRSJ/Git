package bean;
import java.util.ArrayList;

/**
 *
 * @author Junior
 */
public class municipios {
    private  int idM;
    private  String Nome;
    
    public int getIdM() {
        return idM;
    }

    public void setIdM(int idM) {
        this.idM = idM;
    }
    
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    @Override
    public String toString() {
        return getNome(); //To change body of generated methods, choose Tools | Templates.
    }
   
}
