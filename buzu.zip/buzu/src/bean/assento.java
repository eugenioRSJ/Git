
package bean;

/**
 *
 * @author Junior
 */
public class assento {
    private int assento;

    public int getAssento() {
        return assento;
    }

    public void setAssento(int assento) {
        this.assento = assento;
    }

    @Override
    public String toString() {
        return Integer.toString(getAssento()+1); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
