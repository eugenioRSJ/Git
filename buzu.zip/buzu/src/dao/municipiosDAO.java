/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Junior
 */
import bean.municipios;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class municipiosDAO {
    public void create(municipios p) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO MUNICIPIO (NOME) VALUES(?)");
            stmt.setString(1, p.getNome());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public List<municipios> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<municipios> municipio = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM MUNICIPIO");
            rs = stmt.executeQuery();

            while (rs.next()) {

                municipios m = new municipios();
                m.setIdM(rs.getInt("IDMUNICIPIO"));
                m.setNome(rs.getNString("NOME"));
                municipio.add(m);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return municipio;

    }
    public List<municipios> readForDesc(int desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<municipios> municipio = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM MUNICIPIO WHERE IDMUNICIPIO LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                municipios m = new municipios();
                m.setNome(rs.getNString("NOME"));
                municipio.add(m);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return municipio;

    }

    public void update(municipios m) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE MUNICIPIO SET NOME = ? WHERE IDMUNICIPIO = ?");
            stmt.setString(1, m.getNome());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public void delete(municipios p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM MUNICIPIO WHERE IDMUNICIPIO = ?");
            stmt.setInt(1, p.getIdM());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

}
