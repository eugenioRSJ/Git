package dao;

import bean.roteiro;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class roteiroDAO {
    public void create(roteiro r) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO ROTEIRO (IDBUZU, IDMOTORISTA, IDORIGEM, IDDESTINO) VALUES(?, ?, ?, ?)");
            stmt.setInt(1, r.getIdBuzu());
            stmt.setInt(2, r.getIdMotorista());
            stmt.setInt(3, r.getIdOrigem());
            stmt.setInt(4, r.getIdDestino());
            

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public List<roteiro> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<roteiro> roteiro = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM ROTEIRO");
            rs = stmt.executeQuery();

            while (rs.next()) {

                roteiro r = new roteiro();
                r.setId(rs.getInt("IDROTEIRO"));
                r.setIdBuzu(rs.getInt("IDBUZU"));
                r.setIdMotorista(rs.getInt("IDMOTORISTA"));
                r.setIdOrigem(rs.getInt("IDORIGEM"));
                r.setIdDestino(rs.getInt("IDDESTINO"));
                roteiro.add(r);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return roteiro;

    }
    
}
