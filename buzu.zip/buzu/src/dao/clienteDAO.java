
package dao;

import bean.buzu;
import bean.cliente;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class clienteDAO {
    public void create(cliente c) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO CLIENTE (NOME, IDASSENTOBUZU) VALUES (?, ?)");
            stmt.setString(1, c.getNome());
            stmt.setInt(2, c.getCodigoAssento());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public List<cliente> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<cliente> cliente = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM ASSENTOBUZU");
            rs = stmt.executeQuery();

            while (rs.next()) {

                cliente c = new cliente();
                c.setId(rs.getInt("IDCLIENTE"));
                c.setNome(rs.getString("NOME"));
                c.setCodigoAssento(rs.getInt("IDASSENTOBUZU"));
                cliente.add(c);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return cliente;

    }
    public boolean delete(cliente c) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM CLIENTE WHERE NOME = ?");
            stmt.setString(1, c.getNome());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
            return false;
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    public List<cliente> readForDesc(int idBuzu) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        PreparedStatement comp = null;
        ResultSet rs = null;
        List<cliente> client = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM CLIENTE");
            rs = stmt.executeQuery();
            while (rs.next()) {
                cliente cliente = new cliente();
                cliente.setId(rs.getInt("IDCLIENTE"));
                cliente.setNome(rs.getString("NOME"));
                cliente.setCodigoAssento(rs.getInt("IDASSENTOBUZU"));
                if (cliente.getCodigoAssento()== idBuzu)
                    client.add(cliente);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return client;

    }
    
}
