package dao;

/**
 *
 * @author Junior
 */
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import bean.buzu;

public class buzuDAO {
    public void create(int i) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO BUZU VALUES (?)");
            stmt.setInt(1, i);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public List<buzu> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<buzu> buzu = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM BUZU");
            rs = stmt.executeQuery();

            while (rs.next()) {

                buzu b = new buzu();
                b.setIdBuzu(rs.getInt("IDBUZU"));
                buzu.add(b);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return buzu;

    }
    
    public List<buzu> readForDesc(int desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<buzu> buzu = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM BUZU WHERE IDBUZU LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                buzu b = new buzu();
                b.setIdBuzu(rs.getInt("IDBUZU"));
                buzu.add(b);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return buzu;

    }
}
