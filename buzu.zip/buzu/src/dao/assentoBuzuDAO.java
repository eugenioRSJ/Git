package dao;

import bean.assentoBuzu;
import bean.cliente;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class assentoBuzuDAO {
    public void create(assentoBuzu aB) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO ASSENTOBUZU (IDASSENTO, IDBUZU) VALUES (?, ?)");
            stmt.setInt(1, aB.getIdAssento());
            stmt.setInt(2, aB.getIdBuzu());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public List<assentoBuzu> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<assentoBuzu> assento = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM ASSENTOBUZU");
            rs = stmt.executeQuery();

            while (rs.next()) {

                assentoBuzu b = new assentoBuzu();
                b.setId(rs.getInt("IDASSENTOBUZU"));
                b.setIdAssento(rs.getInt("IDASSENTO"));
                b.setIdBuzu(rs.getInt("IDBUZU"));
                assento.add(b);
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return assento;

    }
    
    public List<assentoBuzu> readForDesc(int desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        PreparedStatement comp = null;
        ResultSet rs = null;
        ResultSet c = null;
        List<assentoBuzu> buzu = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM ASSENTOBUZU WHERE IDBUZU LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            rs = stmt.executeQuery();
            comp=con.prepareStatement("SELECT * FROM CLIENTE");
            c=comp.executeQuery();
            while (rs.next()) {
                
                assentoBuzu b = new assentoBuzu();
                b.setId(rs.getInt("IDASSENTOBUZU"));
                b.setIdAssento(rs.getInt("IDASSENTO"));
                b.setIdBuzu(rs.getInt("IDBUZU"));
                buzu.add(b);
                while(c.next()){
                    cliente cliente = new cliente();
                    cliente.setId(c.getInt("IDCLIENTE"));
                    cliente.setNome(c.getString("NOME"));
                    cliente.setCodigoAssento(c.getInt("IDASSENTOBUZU"));
                    if(cliente.getCodigoAssento() == b.getId()){
                        buzu.remove(b);
                    }
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return buzu;

    }
    
    public List<assentoBuzu> readForDescDell(int desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        PreparedStatement comp = null;
        ResultSet rs = null;
        ResultSet c = null;
        List<assentoBuzu> buzu = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM ASSENTOBUZU WHERE IDBUZU LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            rs = stmt.executeQuery();
            comp=con.prepareStatement("SELECT * FROM CLIENTE");
            c=comp.executeQuery();
            while (rs.next()) {
                
                assentoBuzu b = new assentoBuzu();
                b.setId(rs.getInt("IDASSENTOBUZU"));
                b.setIdAssento(rs.getInt("IDASSENTO"));
                b.setIdBuzu(rs.getInt("IDBUZU"));
                buzu.add(b);
                while(c.next()){
                    cliente cliente = new cliente();
                    cliente.setId(c.getInt("IDCLIENTE"));
                    cliente.setNome(c.getString("NOME"));
                    cliente.setCodigoAssento(c.getInt("IDASSENTOBUZU"));
                    if(cliente.getCodigoAssento() != b.getId()){
                        buzu.remove(b);
                    }
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(municipiosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return buzu;

    }
}
