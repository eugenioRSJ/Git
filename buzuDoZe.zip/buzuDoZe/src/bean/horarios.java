
package bean;

/**
 *
 * @author Junior
 */
public class horarios {
    int Saida;
    int Partida;

    public int getSaida() {
        return Saida;
    }

    public void setSaida(int Saida) {
        this.Saida = Saida;
    }

    public int getPartida() {
        return Partida;
    }

    public void setPartida(int Partida) {
        this.Partida = Partida;
    }

    
    
}
