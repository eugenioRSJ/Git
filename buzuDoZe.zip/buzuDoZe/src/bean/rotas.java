
package bean;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class rotas {
    private static ArrayList<viagens> viagem =new ArrayList<viagens>();
    private static ArrayList<motoristas>  motorista = new ArrayList<motoristas>();
    private int duracao;

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = this.duracao+ duracao;
    }
    
    public void adicionarViagem(viagens v){
        this.viagem.add(v);
        JOptionPane.showMessageDialog(null,  "Cadastrado com sucesso");
    }
    public void excluirViagem(viagens v){
        this.viagem.add(v);
    }
    public int quantidaViagem(){
        return this.viagem.size();
    }
    public viagens getViagem(int posicao){
        return this.viagem.get(posicao);
    }
    public void adicionarMotorista(motoristas motorista){
        this.motorista.add(motorista);
    }
    public void excluirMotorista(motoristas motorista){
        this.motorista.remove(motorista);
    }
    public int quantidadeMotorista(){
        return this.motorista.size();
    }
    public motoristas getMotorista(int motorista){
        return this.motorista.get(motorista);
    }
    
}
