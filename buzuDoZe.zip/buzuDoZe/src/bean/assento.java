package bean;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Junior
 */
public class assento {
    private cliente cliente;
    private boolean livre;

    public boolean isLivre() {
        return livre;
    }

    public void setLivre(boolean livre) {
        this.livre = livre;
    }
    public cliente getCliente() {
        return cliente;
    }

    public void setCliente(cliente cli) {
        this.cliente = cli;
    }
    
}
