package bean;

import java.util.ArrayList;

/**
 *
 * @author Junior
 */
public class municipios {
    
    private  String id;
    private  String Nome;
    private static ArrayList <viagens> viagem = new ArrayList<viagens>();
    

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    public void adicionarViagem(viagens v){
        this.viagem.add(v);
    }
    public void excluirViagem(viagens v){
        this.viagem.add(v);
    }
    public int quantidaViagem(){
        return this.viagem.size();
    }
    public viagens getViagem(int posicao){
        return this.viagem.get(posicao);
    }

    @Override
    public String toString() {
        return getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
