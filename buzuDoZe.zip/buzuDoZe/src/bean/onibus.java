package bean;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Junior
 */
public class onibus {
    
    private String id;
    private static assento[] lugares;
    private int qtdLugar;
    private static ArrayList<rotas> rota = new ArrayList<rotas>(); 
    private int horarioPartida;

    public onibus() {
        
    }
    public void Nassentos(int x){
        lugares = new assento[qtdLugar];
        qtdLugar=x;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public int quantidadeLugares(){
        return this.lugares.length;
    }
    public assento getLugares(int posicao){
        return lugares[posicao];
    }
    
    public int getHorarioPartida() {
        return horarioPartida;
    }

    public void setHorarioPartida(int horarioPartida) {
        this.horarioPartida = horarioPartida;
    }
    
    public void adicionarRota(rotas rota){
        this.rota.add(rota);
    }
    public void excluirRota(rotas rota){
        this.rota.remove(rota);
    }
    public int quantidadeRotas(){
        return this.rota.size();
    }
    public rotas getRota(int posicao){
        return this.rota.get(posicao);
    }
    public boolean adicionarPassageiro(int lugar, cliente c){
        if (lugar<qtdLugar && lugar>=0){
            if(lugares[qtdLugar]==null){
                assento a= new assento();
                a.setCliente(c);
                lugares[lugar]= a;
                return true;
            }
            else
                return false;
        }
        else 
            return false;
    }
    public String imprimePassageiros(){
        String lista= "";
        for (int cont=0; cont<qtdLugar; cont++){
 
            if(lugares[cont]!=null){
                lista+="Passageiro: "+ lugares[cont].getCliente().getNome()+" Assento: "+(cont+1);
            }
        }
        return lista;
    }
    public String listarAssentosLivres(){
        String lista= "";
        int contL=0, contCol=0;
        for (int cont=0; cont<qtdLugar; cont++){
            if(lugares[cont]==null){
                lista+=" Assento: "+(cont);
                contL++; contCol++;
                if(contL==2){
                    lista+="   ";
                    contL=0;
                }
                if (contCol== 4){
                    lista+="\n";
                    contCol=0;
                }
            }
            else{
                lista+=" Assento: X";
                contL++; contCol++;
                if(contL==2){
                    lista+="   ";
                    contL=0;
                }
                if (contCol== 4){
                    lista+="\n";
                    contCol=0;
                }
            }
        }
        return lista;
    }

    @Override
    public String toString() {
        return this.getId(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
