package bean;

/**
 *
 * @author Junior
 */
public class motoristas {
    private String nome;
    private double kmMaxima= 0;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getKmMaxima() {
        return kmMaxima;
    }

    public void setKmMaxima(double kmMaxima) {
        this.kmMaxima = this.kmMaxima+kmMaxima;
    }

    @Override
    public String toString() {
        return this.getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
