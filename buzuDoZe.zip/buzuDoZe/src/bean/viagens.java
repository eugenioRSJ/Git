/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class viagens {
    private  int id;
    private  municipios origem;
    private  municipios  destino;
    private  double km;
    private int duracao;
    private int preco;
    private static ArrayList <municipios> municipio = new ArrayList<municipios>();

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }
    
    public void adicionarMunicipio(municipios municipio){
        this.municipio.add(municipio);
        JOptionPane.showMessageDialog(null, quantidaMunicipos()+" Cadastrado com sucesso");
    }
    public void excluirMunicipio(municipios municipio){
        this.municipio.remove(municipio);
    }
    public int quantidaMunicipos(){
        return this.municipio.size();
    }
    public municipios getMunicipio(int posicao){
        return this.municipio.get(posicao);
    }
    public municipios getOrigem() {
        return this.origem;
    }

    public void setOrigem(int id) {
        this.origem = municipio.get(id);
    }

    public municipios getDestino() {
        return this.destino;
    }

    public void setDestino(int  d) {
        this.destino = municipio.get(d);
    }

    public double getKm() {
        return km;
    }

    public void setKm(double km) {
        this.km = km;
    }

    @Override
    public String toString() {
        return "Origem: " +this.origem.getNome()+" Destino: " + this.destino.getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
