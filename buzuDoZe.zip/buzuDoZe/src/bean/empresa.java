
package bean;

/**
 *
 * @author Junior
 */

import java.util.ArrayList;
import javax.swing.JOptionPane;
public class empresa {
    
    private static ArrayList<onibus>  onibus = new ArrayList<onibus>();
    
    public void adicionarOnibus(onibus Onibus){
        this.onibus.add(Onibus);
        JOptionPane.showMessageDialog(null, "Onibus cadastrado com Sucesso");
    }
    public void excluirOnibus(onibus Onibus){
        this.onibus.remove(onibus);
    }
    public int quantidadeOnibus(){
        return this.onibus.size();
    }
    public onibus getOnibus(int posicao){
        return this.onibus.get(posicao);
    } 
    
}
