/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaobd;

import Model.Pessoa;
import dao.pessoaDao;
/**
 *
 * @author Junior
 */
public class teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Pessoa p = new Pessoa();  
       p.setId(1L);
       p.setNome("Eugênio Rocha");
       p.setEmail("eugeniojunior99@gmail.com");
       p.setSenha("eugeniojunior");
       pessoaDao pDao = new pessoaDao();
       pDao.update(p);
       
    }
    
}
