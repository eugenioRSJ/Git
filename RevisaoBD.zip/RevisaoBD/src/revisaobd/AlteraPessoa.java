/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaobd;

import Controller.AlteraPessoaController;
import Model.Pessoa;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Junior
 */
public class AlteraPessoa extends Application {

    public AlteraPessoa(Pessoa p) {
        AlteraPessoaController.setP(p);
    }
    
    
    private static Stage stage;//tela1
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/AlteraPessoa.fxml")); //Carrega FXML
        Scene scene = new Scene(root); //Coloca FXML em uma cena   
        stage.setTitle("Alterar Pessoa"); //seta um titulo
        stage.setScene(scene); //coloca a cena em  uma janela   
        stage.show(); //abre a janela2
        setStage(stage); //seta a janela2 na janela 1
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static Stage getStage() {
        return stage;
    }

    public static void setStage(Stage stage) {
        AlteraPessoa.stage = stage;
    }
    
}
