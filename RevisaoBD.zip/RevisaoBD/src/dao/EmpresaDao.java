/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import JDBC.ConnectionFactory;
import Model.Empresa;
import Model.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Junior
 */
public class EmpresaDao {
    
    public boolean create(Empresa e) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO EMPRESA (NOME, CNPJ) VALUES(?, ?)");
            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getCnpj());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
            return true;
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public void update(Empresa e) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE EMPRESA SET NOME = ?, CNPJ = ? WHERE ID = ?");
            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getCnpj());
            stmt.setLong(3, e.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public List<Empresa> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Empresa> empresa = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM EMPRESA");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Empresa e = new Empresa();
                e.setId(rs.getLong("ID"));
                e.setNome(rs.getString("NOME"));
                e.setCnpj(rs.getString("CNPJ"));
                empresa.add(e);
            }

        } catch (SQLException ex) {
            Logger.getLogger(dao.pessoaDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return empresa;

    }
    
    public void delete(Empresa e) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM EMPRESA WHERE ID = ?");
            stmt.setLong(1, e.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
}
