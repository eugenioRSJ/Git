/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Junior
 */

import Model.Pessoa;
import JDBC.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class pessoaDao {
    public boolean create(Pessoa p) {
        
        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO PESSOA (NOME, EMAIL, SENHA) VALUES(?, ?, ?)");
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());
            stmt.setString(3, p.getSenha()); 
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
            return true;
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

    public List<Pessoa> read() {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Pessoa> pessoa = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM PESSOA");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Pessoa p = new Pessoa();
                p.setId(rs.getLong("ID"));
                p.setNome(rs.getNString("NOME"));
                p.setEmail(rs.getString("EMAIL"));
                p.setSenha(rs.getString("SENHA"));
                pessoa.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(pessoaDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        System.out.println("entrei no banco");
        return pessoa;

    }
    public List<Pessoa> readForDesc(String desc) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Pessoa> pessoa = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM PESSOA WHERE nome LIKE ?");
            stmt.setString(1, "%"+desc+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Pessoa p = new Pessoa();
                p.setId(rs.getLong("ID"));
                p.setNome(rs.getNString("NOME"));
                p.setEmail(rs.getString("EMAIL"));
                p.setSenha(rs.getString("SENHA"));
                pessoa.add(p);
            }

        } catch (SQLException ex) {
            Logger.getLogger(pessoaDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return pessoa;

    }

    public void update(Pessoa p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE PESSOA SET NOME = ?, EMAIL = ?, SENHA = ?  WHERE ID = ?");
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getEmail());
            stmt.setString(3, p.getSenha());
            stmt.setLong(4, p.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    public void delete(Pessoa p) {

        Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("DELETE FROM PESSOA WHERE ID = ?");
            stmt.setLong(1, p.getId());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }

}
