/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pessoa;
import dao.pessoaDao;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.Login;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class LoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private TextField txtEmail;

    @FXML
    private Button btnLogar;

    @FXML
    private PasswordField txtSenha;

    @FXML
    private Button btnSair;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btnSair.setOnMouseClicked((MouseEvent e) -> {
            fechar();
        });
        
        btnSair.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode()== KeyCode.ENTER)
                fechar();
        });
        btnLogar.setOnMouseClicked((MouseEvent e) -> {                
            logar();
        });
        
        btnLogar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                logar();
            }
            
        });
        txtSenha.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                logar();
            }
            
        });
        
    }    
    
    public void fechar(){
        Login.getStage().close();
    }
    public void logar(){
            List<Pessoa> pessoa = new pessoaDao().read();
            for (int i = 0; i < pessoa.size(); i++) {
                if (txtEmail.getText().equals(pessoa.get(i).getEmail()) && txtSenha.getText().equals(pessoa.get(i).getSenha())){
                    i=pessoa.size();
                    Principal p = new Principal();
                    try {
                        p.start(new Stage());
                        fechar();
                    } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else{
                    
                    if(i == pessoa.size() - 1){
                        Alert a = new Alert(AlertType.ERROR);
                        a.setHeaderText("Erro ao Logar");
                        a.setTitle("Error");
                        a.setContentText("Usuario invalido");
                        a.show();
                    }
                }
            }
    }
}
