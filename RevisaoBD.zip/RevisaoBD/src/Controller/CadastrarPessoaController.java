/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pessoa;
import dao.pessoaDao;
import java.awt.event.MouseAdapter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.CadastrarEmpresa;
import revisaobd.CadastrarPessoa;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class CadastrarPessoaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private TextField txtNome;
    @FXML private TextField txtEmail;
    @FXML private PasswordField txtSenha;
    @FXML private Button btnCadastrar;
    @FXML private Button btnCancelar;
    @FXML private PasswordField txtConfirmarSenha;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btnCadastrar.setOnMouseClicked((MouseEvent e) -> {
            CadastrarPessoa();
        });
        btnCadastrar.setOnKeyPressed((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                CadastrarPessoa();
            }
        });
        
        btnCancelar.setOnMouseClicked((MouseEvent e) -> {abirPrincipal();});
        btnCancelar.setOnKeyPressed((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                abirPrincipal();
            }
        });
        
    }    
    
    public void fecha(){
        CadastrarPessoa.getStage().close();
    }
    public void abirPrincipal(){
        Principal p = new Principal();
        try {
            p.start(new Stage());
            fecha();
        } catch (Exception ex) {
            Logger.getLogger(CadastrarPessoaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void CadastrarPessoa(){
        String nome = txtNome.getText(), 
               email = txtEmail.getText(), 
               senha = txtSenha.getText(), 
               confirmacao = txtConfirmarSenha.getText();
        if (nome.equals("") || email.equals("") || senha.equals("") || confirmacao.equals("")){
            Alert al = new Alert(AlertType.ERROR);
            al.setTitle("Error");
            al.setHeaderText("Existem espaços em branco");
            al.show();
        }
        else{
            if (senha.equals(confirmacao)){
                Pessoa p = new Pessoa(nome, email, senha);
                pessoaDao pDao = new pessoaDao();
                if (pDao.create(p)){
                    abirPrincipal();
                }else{
                    Alert a = new Alert(AlertType.ERROR);
                    a.setHeaderText("Usuario não cadastrado");
                    a.showAndWait();
                }
            }else{
                Alert a = new Alert(AlertType.ERROR);
                a.setHeaderText("Senhas não coincidem");
                a.showAndWait();
            }
        }
        
    }
    
}
