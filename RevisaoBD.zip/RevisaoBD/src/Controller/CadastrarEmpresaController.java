/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.EmpresaDao;
import Model.Empresa;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.CadastrarEmpresa;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class CadastrarEmpresaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private TextField txtNome;
    @FXML private TextField txtCnpj;
    @FXML private Button btnCadastrar;
    @FXML private Button btnCancelar;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnCadastrar.setOnMouseClicked((MouseEvent e) -> {cadastrarEmpresa();});
        btnCadastrar.setOnKeyPressed((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                cadastrarEmpresa();
            }
        });
        btnCancelar.setOnMouseClicked((MouseEvent e) -> {});
        btnCancelar.setOnKeyPressed((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
            
            }
        });
    }
    
    private void fecha(){
        CadastrarEmpresa.getStage().close();
    }
    private void abrirPrincipal(){
        Principal p = new Principal();
        try {
            p.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(CadastrarEmpresaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void cadastrarEmpresa(){
        String nome = txtNome.getText(), cnpj = txtCnpj.getText();
        Empresa e = new Empresa(nome, cnpj);
        EmpresaDao eDAo = new EmpresaDao();
        if (eDAo.create(e)){
            
        }
        else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setHeaderText("Erro ao cadastrar empresa");
        }
    }
    
}
