/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import dao.EmpresaDao;
import Model.Empresa;
import Model.Pessoa;
import dao.pessoaDao;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.CadastrarEmpresa;
import revisaobd.CadastrarPessoa;
import revisaobd.ListarEmpresa;
import revisaobd.ListarPessoa;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class PrincipalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private Button btnCadastrarPessoa;

    @FXML private Button btnListarEmpresa;

    @FXML private Button btnListarPessoa;

    @FXML private Button btnCadastrarEmpresa;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btnCadastrarEmpresa.setOnMouseClicked((MouseEvent e) ->{
            abreCadastroEmpresa();
        });
        
        btnCadastrarEmpresa.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                abreCadastroEmpresa();
            }
        });
        
        btnCadastrarPessoa.setOnMouseClicked((MouseEvent e) ->{
            abreCadastroPessoa();
        });
        
        btnCadastrarPessoa.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                abreCadastroPessoa();
            }
        });
        
        btnListarPessoa.setOnMouseClicked((MouseEvent e) -> {
            listarPessoa();
        });
        
        btnListarPessoa.setOnKeyPressed((KeyEvent e)-> {
            if (e.getCode() == KeyCode.ENTER){
                listarPessoa();
            }
        });
        btnListarEmpresa.setOnMouseClicked((MouseEvent e) -> {
            listarEmpresa();
        });
        
        btnListarEmpresa.setOnKeyPressed((KeyEvent e)-> {
            if (e.getCode() == KeyCode.ENTER){
                listarEmpresa();
            }
        });
        
    }   
    
    public void abreCadastroPessoa(){
        CadastrarPessoa cadPessoa = new CadastrarPessoa();
        try {
            cadPessoa.start(new Stage());
            fechar();
        } catch (Exception ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void abreCadastroEmpresa(){
        CadastrarEmpresa cadEmpresa = new CadastrarEmpresa();
        try {
            cadEmpresa.start(new Stage());
            fechar();
        } catch (Exception ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void fechar(){
        Principal.getStage().close();
    }
    
    public void listarEmpresa(){
        ListarEmpresa lEm = new ListarEmpresa();
        try {
            lEm.start(new Stage());
            fechar();
        } catch (Exception ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void listarPessoa(){
        ListarPessoa p = new ListarPessoa();
        try {
            fechar();
            p.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
