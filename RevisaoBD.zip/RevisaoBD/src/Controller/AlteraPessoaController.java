/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pessoa;
import dao.pessoaDao;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.AlteraPessoa;
import revisaobd.ListarPessoa;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class AlteraPessoaController implements Initializable {

    @FXML private TextField txtNome;
    @FXML private TextField txtEmail;
    @FXML private PasswordField txtSenha;
    @FXML private PasswordField txtConfirmarSenha;
    @FXML private Button btnAtualizar;
    @FXML private Button btnCancelar;
    @FXML private Label lbId;
    private static Pessoa p;
    /**
     * Initializes the controller class.
     */
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initPerson();
        btnCancelar.setOnMouseClicked((MouseEvent e) -> {
            AlteraPessoa.getStage().close();
        });
        
        btnCancelar.setOnKeyPressed(((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                AlteraPessoa.getStage().close();
            }
        }));
        
        btnAtualizar.setOnMouseClicked((MouseEvent e) -> {
            abrirLista();
            AlteraPessoa.getStage().close();
            atualiza();
            
        });
        
        btnAtualizar.setOnKeyPressed(((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                abrirLista();
                AlteraPessoa.getStage().close();
                atualiza();
                
                
            }
        }));
    } 
    
    public void abrirLista(){
        ListarPessoa pes = new ListarPessoa();
                try {
                    pes.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(AlteraPessoaController.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    public void initPerson(){
        lbId.setText(p.getId().toString());
        txtNome.setText(p.getNome());
        txtEmail.setText(p.getEmail());
        txtSenha.setText(p.getSenha());
        txtConfirmarSenha.setText(p.getSenha());
   }

    public static Pessoa getP() {
        return p;
    }

    public static void setP(Pessoa p) {
        AlteraPessoaController.p = p;
    }
    
    public void atualiza(){
        Pessoa p1 = new Pessoa();
        p1.setId(Long.parseLong(lbId.getText()));
        p1.setNome(txtNome.getText());
        p1.setEmail(txtEmail.getText());
        p1.setSenha(txtSenha.getText());
        if(txtSenha.getText().equals(txtConfirmarSenha.getText())){
            pessoaDao dao = new pessoaDao();
            dao.update(p1);
        }
        else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setHeaderText("senha não coincide ");
        }
        
    }
   
}
