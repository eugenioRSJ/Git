/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pessoa;
import dao.pessoaDao;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.AlteraPessoa;
import revisaobd.ListarPessoa;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class ListarPessoaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private TableView<Pessoa> tabela;
    @FXML private TableColumn<Pessoa, Long> clmId;
    @FXML private TableColumn<Pessoa, String> clmNome;
    @FXML private TableColumn<Pessoa, String> clmEmail;
    @FXML private Button btnDeletar;
    @FXML private Button btnAtualizar;
    @FXML private Button btnCancelar;
    @FXML private Button btnAlterar;

    private Pessoa pSelcionada;  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initTable();
        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                pSelcionada=(Pessoa) newValue;
                
            }
        });
        
        btnCancelar.setOnMouseClicked((MouseEvent e) -> {
            abrirPrincipal();
        });
        
        btnCancelar.setOnKeyPressed(((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                abrirPrincipal();
            }
        }));
        
        btnDeletar.setOnMouseClicked((MouseEvent e) -> {
            deletarPessoa();
        });
        
        btnDeletar.setOnKeyPressed((KeyEvent e) ->{
            if (e.getCode() == KeyCode.ENTER){
                deletarPessoa();
                }
        });
        
        btnAtualizar.setOnMousePressed((MouseEvent e) -> {
            atualizaPessoa();
        });
        
        btnAtualizar.setOnKeyPressed((KeyEvent e) -> {
            if(e.getCode() == KeyCode.ENTER){
                atualizaPessoa();
            }
        });
        
        btnAlterar.setOnMouseClicked((MouseEvent e) -> {
            abrirAlterar();
        });
        btnAlterar.setOnKeyPressed((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                abrirAlterar();
            }
        });
                
    }

    public void atualizaPessoa(){
        tabela.setItems(atualizarTabela());
        
    }
    public void deletarPessoa(){
        if (pSelcionada != null){
            pessoaDao  dao = new pessoaDao();
            dao.delete(pSelcionada);
            tabela.setItems(atualizarTabela());
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setHeaderText("Pessoa não selecionada");
        }
            
        
    }
    
    
    
    public List<Pessoa>  listarPessoa(){
        List<Pessoa> pessoa = new pessoaDao().read();
        
        return  pessoa;
    }
    public void initTable(){
        clmId.setCellValueFactory(new PropertyValueFactory("id"));
        clmNome.setCellValueFactory(new PropertyValueFactory("nome"));
        clmEmail.setCellValueFactory(new PropertyValueFactory("email"));
        tabela.setItems(atualizarTabela());
    }
    
    public ObservableList<Pessoa> atualizarTabela(){
        ObservableList<Pessoa> obd = FXCollections.observableArrayList(listarPessoa());
        return obd;
    }
    
    public void fechar(){
        ListarPessoa.getStage().close();
    }
    public void abrirPrincipal(){
        Principal prin = new Principal();
        try {
            prin.start(new Stage());
            fechar();
        } catch (Exception ex) {
            Logger.getLogger(ListarPessoaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void abrirAlterar(){
        if(pSelcionada != null){
            AlteraPessoa ap = new AlteraPessoa(pSelcionada);
            try {
                ap.start(new Stage());
                fechar();
            } catch (Exception ex) {
                Logger.getLogger(ListarPessoaController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setHeaderText("Pessoa não selecionada");
        }
            
    }
    
}
