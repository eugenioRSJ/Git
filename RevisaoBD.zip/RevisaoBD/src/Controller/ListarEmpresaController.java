/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Empresa;
import dao.EmpresaDao;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import revisaobd.ListarEmpresa;
import revisaobd.Principal;

/**
 * FXML Controller class
 *
 * @author Junior
 */
public class ListarEmpresaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private TableView<Empresa> tabela;
    @FXML private TableColumn<Empresa, Long> clmId;
    @FXML private TableColumn<Empresa, String> clmNome;
    @FXML private TableColumn<Empresa, String> clmCNPJ;
    @FXML private Button btnDeletar;
    @FXML private Button btnAtualizar;
    @FXML private Button btnCancelar;
    private Empresa empresa;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        initTable();
        tabela.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                empresa = (Empresa) newValue;
            }
        });
        
        
        btnCancelar.setOnMouseClicked((MouseEvent e) -> {
            irPrincipal();
        });
        
        btnCancelar.setOnKeyPressed ((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
               irPrincipal();
            }
        } );
        btnAtualizar.setOnMouseClicked((MouseEvent e) -> {
            atualizarTabela();
        });
        
        btnAtualizar.setOnKeyPressed ((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                atualizarTabela();
            }
        } );
        
        btnDeletar.setOnMouseClicked((MouseEvent e) -> {
            deletar();
        });
        
        btnDeletar.setOnKeyPressed ((KeyEvent e) -> {
            if (e.getCode() == KeyCode.ENTER){
                deletar();
            }
        } );
    }    
    
    public List<Empresa> listarEmpresa(){
        List<Empresa> empresa = new EmpresaDao().read();
        for(int i=0; i< empresa.size(); i++){
            empresa.get(i).mostrarEmpresa();
        }
        return  empresa;
    }
    public void initTable(){
        clmId.setCellValueFactory(new PropertyValueFactory("id"));
        clmNome.setCellValueFactory(new PropertyValueFactory("nome"));
        clmCNPJ.setCellValueFactory(new PropertyValueFactory("cnpj"));
        tabela.setItems(atualizarTabela());
    }
    
    public ObservableList<Empresa> atualizarTabela(){
        ObservableList<Empresa> obd = FXCollections.observableArrayList(listarEmpresa());
        return obd;
    }
    
    public void fechar(){
        ListarEmpresa.getStage().close();
    }
    
    public void irPrincipal(){
        Principal p = new Principal();
        try {
            p.start(new Stage());
            fechar();
        } catch (Exception ex) {
            Logger.getLogger(ListarEmpresaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deletar(){
        EmpresaDao dao = new EmpresaDao();
        dao.delete(empresa);
        tabela.setItems(atualizarTabela());
    }

}
